# Skyhigh Secure Web Gateway: Aetna vs. CVS Health — Complete Configuration Analysis

**Sources (unpacked and parsed directly from XML — nothing below is reconstructed from memory or summarized from a prior pass):**
- `Aetna-SH-Proxy-2026-07-21_backup.zip` → snapshot `2026-07-17_15-24-36-042_-0400`
- `CVS-roxy-SH-2026-07-16_backup.zip` → snapshot `2026-06-03_13-21-51-187_-0400`

Both backups were decompressed (gzip → tar) and every one of the three list namespaces they contain was walked in full: `lists/*.xml` (top-level custom objects), `lists/subscribed_lists/customer/*.xml` (customer-fetched objects), and `lists/subscribed_lists/update_server/*.xml` (vendor-fetched objects) — plus `cfg/*.xml` (policy engine objects), `library/RuleGroups/custom/*.xml` (rule groups), and the compiled `gwrs.xml` (the live, effective rule tree, ~400+ rules per side). All numeric category and DLP-category IDs referenced below were resolved against the master lookup table embedded in each backup (`lists/system_lists/dynTypeOps/com.scur.type.category.xml`), not left as opaque tokens.

---

## 1. Platform Parity

| Item | Aetna | CVS |
|---|---|---|
| Product build | `12.2.23` build `57025`, hotfix 0 | `12.2.23` build `57025`, hotfix 0 — **identical** |
| Cluster node count | **15 nodes** | **8 nodes** |
| `cfg/` policy objects (top-level) | 178 | 185 |
| `lists/*.xml` (top-level custom lists) | 191 | 178 |
| `lists/subscribed_lists/customer/*.xml` | **100** | **129** |
| `lists/subscribed_lists/update_server/*.xml` | 34 | 36 |
| Custom Rule Groups (`library/RuleGroups/custom`) | 4 files | 3 files |

Software build is identical on both sides — every difference documented below is a policy-authoring difference, not a version-skew artifact.

---

## 2. Object Namespaces — what exists and what's actually in it

Skyhigh SWG splits list objects into three distinct namespaces with three different maintenance models. This distinction matters because it determines what can and cannot be recovered from a coordinator backup:

| Namespace | Maintenance model | Content present in this backup? |
|---|---|---|
| `lists/*.xml` | Manually authored in the SWG UI, stored inline | **Yes** — full content embedded |
| `lists/subscribed_lists/customer/*.xml` | `feature="CUSTOMER_MAINTAINED"` — fetched on a timer from an external HTTP(S) URL | **No** — only the fetch URL, credentials field, and refresh interval are stored; `<content/>` is empty in the export |
| `lists/subscribed_lists/update_server/*.xml` | `feature="MCAFEE_MAINTAINED"` — vendor infrastructure lists (WebEx/Citrix/Windows Update IP ranges, vendor-maintained CA bundle) fetched from McAfee/Skyhigh's own update servers | **No**, same reason — and not policy-relevant even if it were, since these are vendor CDN/infra ranges, not authored content |

**This is a hard data-availability boundary, not an extraction gap.** Confirmed by direct inspection — every one of the 100 (Aetna) / 129 (CVS) customer-namespace objects carries `feature="CUSTOMER_MAINTAINED"` and an empty `<content/>` tag. Example, verbatim:

```xml
<list feature="CUSTOMER_MAINTAINED" ... name="AllowListProd: Domains" ...>
  <setup>
    <connection>
      <url>https://proxyconsole.aetna.com/prod/AllowListProd.domains.txt</url>
      ...
    </connection>
    <updateTime><every value="20" unit="Minutes"/></updateTime>
  </setup>
  <content/>
</list>
```

**Notable finding:** every customer-maintained list on *both* estates — including CVS's own `AllowListProd_CVS`, `NoAuthProd_CVS`, `DenyListProd_CVS`, and the entire `HTTPS Scanning Opt In/Out` lattice — fetches from the same console hostname: **`proxyconsole.aetna.com`**. CVS Health's proxy estate has never migrated its dynamic-list distribution off the legacy Aetna console, even for CVS-specific object names created after the naming convention diverged. If a list-content extraction is ever needed for a full DLP/URL-policy audit, it has to come from that console directly (or from a live appliance `list export`), not from either backup file — no combination of re-parsing gets you there.

Full URL/refresh-interval table is in **Appendix D**.

The vendor-maintained (`update_server`) namespace was inspected and confirmed to contain only infrastructure objects — `WebEx IP Ranges`, `Citrix IP Ranges`, `Windows Update Hosts`, `Windows Update User-Agents`, `Windows Activation Hosts`, and `Certificates: Known CAs (McAfee Maintained)` — vendor-published reference data, not customer policy. Not itemized further since it carries no comparative signal between the two estates.

---

## 3. Authentication Model

**Aetna** — single mechanism, static exemptions:
```
Authenticate With NTLM
```
preceded by a long flat list of static IP-range/domain bypass rules (Mobile DMZ, SCOM, VDMZ, CVTY Citrix, NoAuthProd URLs, Corporate Display Server, BigTinCan, Aetna MSLync→Office365, vSOC, Checkpoint, ThousandEyes). No Kerberos. No explicit-proxy-port gating on the bypass logic — it's unconditional.

**CVS** — tiered, protocol-aware:
- `SourceIPNoAuth` / `SourceIPRangeNoAuth` bypass is gated specifically to `ExplicitProxyPortListForSourceIPNoAuth` — tighter than Aetna's unconditional bypass.
- Three parallel authentication passes exist for three deployment modes:
  1. Simple: `Authenticate With NTLM`
  2. WCCP-transparent: `Redirect Clients That do Not Have a Valid Session to the Authentication Server` → `WCCP Authenticate User Against Kerberos-MAC` → redirect-back → `WCCP Authenticate User Against NTLM` fallback
  3. Explicit-proxy: `Explicit Authenticate With Kerberos` → `Stop if Kerberos Authenticated` → `Explicit Authenticate With NTLM` fallback
- `Clear Authentication cache` exists as a disabled operational kill-switch ahead of each pass — no equivalent object exists anywhere in Aetna's config.

**Assessment:** CVS runs a Kerberos-first, three-mode auth architecture; Aetna runs NTLM-only with blanket static exemptions. If unifying, CVS's ruleset is the defensible reference — Aetna's would need the Kerberos/WCCP branches built from scratch, not just an object merge.

---

## 4. HTTPS/TLS Content Inspection — full detail

### 4.1 Live rule-chain behavior

**Aetna** — single linear chain, repeated twice in the compiled ruletree (once gated by a `ProdVontuSSL` exception, once not), both passes using **Block** actions:
```
Enable Certificate Verification
 → Skip Certificate Verification (AllowCerts: Domains)
 → Block Self-Signed / Expired / Chain-too-long / Revoked / Unknown-CA / Untrusted-CA / Weak-Key-Exchange
 → Verify Safe Signature Algorithms → Block unsafe Signature Algorithms
 → Allow Matching Host Name / Wildcard / Alt Common Names
 → Block Incident
 → Enable Content Inspection: SSL-Inspect-Cat OR YouTube:Domains OR ProdSSLinspect:Domains OR ProdSSLinspect:URLs
```
Decrypt trigger is **categorical and on by default** for anything in `SSL-Inspect-Cat`. The library rule group this is drawn from is named **"Certificate Verification - Monitor Only"**, but the compiled ruletree shows `Block`, not `Monitor`, in both live passes — a naming/behavior mismatch worth validating directly against the live appliance UI, since a stale or renamed library object is exactly the kind of thing that produces policy-intent drift.

**CVS** — three-tier posture, decrypt is **opt-in by default**:
1. **Monitor tier:** same checks as Aetna, but `Monitor` actions, feeding `Monitor Incident`.
2. **Mixed tier:** same checks, `Monitor` except `Block unsafe Signature Algorithms` and `Block Incident`, which are hard blocks.
3. **Full-block tier:** same checks, all `Block`, feeding `Enable Content Inspection Always for HTTPS Scanning Opt In`.

Decryption itself only fires after passing one of 8 independent opt-in gates:
```
Enable HTTPS Scanning By: Domain Opt In | Category Opt In | Domain REGEX Opt In |
                           User-Agent Opt In | Source IP Opt In | Destination IP Opt In |
                           Source IP Range Opt In | Destination IP Range Opt In
 → Bypass HTTPS Scanning if Above Rules did not Opt In   (explicit default-deny catch-all)
```
plus a dedicated **Slack** opt-in path and a **Trial Run** cohort path ahead of the general one — evidence of a formal staged-rollout methodology that doesn't exist anywhere in Aetna's config.

### 4.2 Resolved `SSL-Inspect-Cat` / `SSL-Inspect-Monitor-Cat` contents

These category-type lists don't store names inline — they store numeric `com.scur.category.N` references. Resolved against the master category table embedded in each backup:

| List | Aetna resolved categories | CVS resolved categories |
|---|---|---|
| `SSL-Inspect-Cat` (9 vs 8 entries) | Blogs/Wiki, Chat, Messaging, Search Engines, Visual Search Engines, **Content Server**, Personal Network Storage, Text Translators, Social Networking | Blogs/Wiki, Chat, Messaging, Search Engines, Visual Search Engines, Personal Network Storage, Text Translators, Social Networking |
| `SSL-Inspect-Monitor-Cat` (2 entries, identical both sides) | Forum/Bulletin Boards, Personal Pages | Forum/Bulletin Boards, Personal Pages |

**Delta: Aetna decrypts the "Content Server" category (`com.scur.category.177`); CVS's identically-named list does not carry that entry.** This is a real, substantive policy difference sitting inside two lists with the same name and the same type — the kind of thing that only surfaces by resolving the IDs, not by comparing list names.

### 4.3 What is and isn't recoverable here

`SSL Tunnel: Bypass Domains/URLs/Categories/Destination IP` and `SSL-Inspect-SHA256/SHA1` are top-level lists with real embedded content on both sides (see Appendix C for the IP/CIDR ones). But the lists that actually decide *which specific domains* get decrypted — `ProdSSLinspect: Domains/URLs`, `ProdVontuSSL: Domains/URLs`, `Bypass-SSLinspect: Domains`, `AllowCerts: Domains`, and (CVS only) the full opt-in/opt-out domain/category/IP lattice — are all `CUSTOMER_MAINTAINED` stubs per §2. Their contents are not in either backup. See Appendix D for the complete list of what's missing and where it actually lives.

---

## 5. DLP

### 5.1 Aggregate counts

| | Aetna | CVS |
|---|---|---|
| `dlpdict.conf` (dictionaries) | 16 | **41** |
| `dlpcat.conf` (classification categories) | 4 | **9** |

### 5.2 Categories present in CVS, absent from Aetna
Classification: `DLP Classification: HIPAA`, `DLP Classification: SOX`, `SSNs`, `SSN & PCI`. Aetna's only classifications are `DLP Dictionary: Acceptable Use`, `DLP Classification: Payment Card Industry`, `CVS Health SSN`.

Dictionaries: `CVS Health Bank Account Number` (+Keywords/Exclusions), `CVS Health AWS Keys`, `CVS Health Passwords`, `DLP IBAN Regex`, `DLP Routing Number Regex`, `DLP CID Regex`, plus a legacy `AETH S ID`/`AETH A ID` regex family predating Aetna's own current dictionary numbering.

### 5.3 Live DLP block chain

**Aetna** (single taxonomy, direction-duplicated — same rules run twice with the tail toggled, consistent with independent REQMOD/RESPMOD control):
```
Masked SSN → HICN → GEMS ID → Dependent ID → Member ID → Long Member ID → FIUO Keywords
 → Cloud Storage (Non-Restricted/Restricted) Block → Restricted Post/Upload Block
 → External SPO Restricted Block → [Aetna Connect Restricted Block XOR HTTP Member ID Block]
 → For Internal Use Only Audit → Acceptable Use
```
**CVS** (same core checks + a first-class Banking category + branded composite actions):
```
Masked SSN → HICN → GEMS ID → Dependent ID → Member ID → Long Member ID → FIUO Keywords
 → Banking → CVS Health SSN HICN Block → CVS Health PCI Block → CVS Health Member ID
 → CVS Health Banking Block → CVS Health Passwords Block (disabled)
 → Acceptable Use → CVS Health SSN HICN Block → CVS Health PCI Block
 → CVS Health Member ID → CVS Health Banking Block
```
CVS's access log has a `Write BankAccount log` entry with no equivalent in Aetna's log ruleset — Aetna has no logging hook for banking-data DLP hits even if the dictionary existed.

**Full verbatim dictionary and regex contents: Appendix A. Classification-category built-in references: Appendix B.**

---

## 6. Anti-Malware Engine Tuning

**Aetna** — 9 objects, two overlapping naming families:

| Object | Name | MinimumBlockThreatRating | StopScanOnVirus | AntivirusAndAntimalware |
|---|---|---|---|---|
| 17711 | Gateway Anti-malware: ICAP Settings | 80 | false | false |
| 17914 | Gateway Anti-Malware: Standard Setting | 90 | false | false |
| 18780 | Gateway Anti-malware: High Setting | 85 | false | **true** |
| com.scur.engine.antivirus.17091 | Gateway Anti-Malware (base) | 90 | false | false |
| com.scur.engine.antivirus.90743573 | Gateway Anti-Malware Streaming | 90 | true | false |
| 958983948401655 | Anti-Malware: Standard Setting | **95** | true | false |
| 958983948401656 | Anti-Malware: Default Setting | 90 | true | false |
| 958983948401657 | Anti-Malware: Quarantine Setting | 85 | true | false |
| 958983948401658 | Anti-Malware: High Setting | **80** | false | false |

Internal inconsistency: **"High Setting" = 85 in one naming family, 80 in the other** — worth reconciling on its own, independent of any CVS comparison.

**CVS** — 2 objects, flat:

| Object | Name | MinimumBlockThreatRating | AntivirusAndAntimalware |
|---|---|---|---|
| 4589 | Gateway Anti-Malware | 90 | false |
| 90743573 | Gateway Anti-Malware Streaming | 90 | false |

CVS runs a single uniform gateway-AV posture; Aetna runs (and has partially lost coherence in) a multi-tier one.

---

## 7. ICAP-Based Content Inspection

**Aetna** — request-direction only. All named ICAP server lists are `*Reqmod.Servers` / `*ReqMod.Servers`: `Aett.Reqmod.Servers`, `Pdc.ReqMod.Servers`, `Mid.ReqMod.Servers`, `Win.ReqMod.Servers`, `QA.ReqMod.Servers`, plus load-balancer VIP `qaqwebprevent-VIP`. Live chain:
```
Call MID ReqMod Server → Call WIN ReqMod Server → Call PDC ReqMod Server → Call QA ReqMod Server
 → (disabled) LAB Only: Call AETT ReqModServer
```
**No `RespMod` list object exists anywhere in Aetna's config.** Confirmed by full-tree search — response-direction (download) ICAP scanning is architecturally absent.

**CVS** — both directions, plus a third-party engine:
```
Call SHEA ReqMod Server (disabled) → Call RI ReqMod Server (enabled)      [REQMOD]
Call ReqMod Server (enabled)                                              [generic/DLP path]
Skip RespMod Server for Responses Without a Body → Call RespMod Server    [RESPMOD]
```
CVS additionally carries a `Symantec` ICAP server object with no Aetna equivalent — third-party AV/DLP integration alongside the built-in Gateway Anti-Malware engine.

**Data-quality flag found while extracting these:** CVS's `ReqMod Server` (generic) and `RespMod Server` objects resolve to `icap://0.0.0.0:1344/reqmod` and `icap://0.0.0.0:1344/respmod` — unbound placeholder addresses — while both calling rules are `enabled=true` in the live ruletree. Either this is overridden per-node (each of the 8 CVS nodes may carry its own real IP via a node-local config layer not captured at this object level) or these two calls are currently non-functional in production. Worth a direct check against the live appliance rather than assuming either way from the backup alone.

---

## 8. Custom Rule Groups (`library/RuleGroups/custom`)

**Aetna** (4 groups): `Bypass Microsoft (Office 365) Services` (13 rules), `export` (13 rules — incident/error notification pipeline), `Certificate Verification - Monitor Only` (15 rules — see §4.1 naming/behavior mismatch), `Access Log` (3 rules).

**CVS** (3 groups): `Common Rules` (39 rules — F5 health check, DMZ/PCI tagging, geolocation, YouTube safety, URL-filter primitives; contains a **disabled** `Allow Aetna DMZs` rule — see §9), `HTTPS Scanning Fresh Import` (29 rules — initial/legacy decrypt logic), `HTTPS Scanning Opt In` (76 rules — the full graduated opt-in model described in §4.1).

---

## 9. Estate-Lineage Evidence

Both configs share an unmistakable common ancestor: many rules are byte-identical in name and structure (`Categorize em All`, `F5 Health Check`, `Tag DMZ Clients`, `System:Statistics`, `ResetCounters-1..5`, the YouTube/Facebook/Twitter/Box application-control blocks, and the entire incident-notification/log-manager chain).

Direct evidence of divergence since that shared baseline:
- A rule literally named **`Allow Aetna DMZs`** exists in both. On Aetna's own proxy it is `enabled=true`. On CVS's copy of the identical rule it is `enabled=false` — CVS has explicitly turned off a legacy Aetna-DMZ bypass that Aetna's own live config still runs.
- Both estates fetch their customer-maintained lists from the same console — `proxyconsole.aetna.com` — including CVS-specific object names (§2). CVS's dynamic-list distribution has never been migrated onto CVS-owned infrastructure.
- Both carry independently-numbered but identically-named IP-range objects (`Mobile DMZ`, `PCI Enclave`, `DMZ Networks`, `Interoperability_Enclave`, `CVTY Citrix`) — the same logical objects, no shared object store, consistent with the broker-agnostic object-store gap.

---

## 10. Complete Object Inventory — all three namespaces, both estates

### 10.1 Top-level `lists/*.xml` (named, manually-authored objects)
191 (Aetna) vs. 178 (CVS). 62 exist only in Aetna, 49 only in CVS. Full itemized delta with resolved types was covered in the prior message in this conversation (regional ICAP/proxy pools, rule-tracing/debug lists, legacy `Mc*` category lists on the Aetna side; F5 VIP objects, CVS-specific category lists, OS/browser user-agent fingerprint lists, and the `CVS Health *Allow` DLP-exception family on the CVS side).

### 10.2 `lists/subscribed_lists/customer/*.xml` (customer-maintained, externally fetched)
**100 (Aetna) vs. 129 (CVS). 83 shared by name, 17 unique to Aetna, 46 unique to CVS.**

Only in Aetna: `AetSharepoint: Domains`, `AllowAIChatbot: URLS`, `AllowAIChatbot:Domains`, `AllowLimited: Domains`, `AllowLimited: URLs`, `Blocked Hosts`, `CoventryExtranet: Domains`, `Prod_Infosec_Redirect: Domains`, `Prod_Infosec_Redirect: URLs`, `Prod_cloudStorage_coach: Domains`, `Prod_cloudStorage_coach: URLs`, `QAFireglass: Domains`, `Response WhiteList: URLs`, `VDMZAllowList: Domains`, `VDMZAllowList: URLs`, `VDMZDenyList: Domains`, `VDMZDenyList: URLs`.

Only in CVS: the full 16-object `HTTPS Scanning By [Domain|Category|Domain REGEX|Source IP|Destination IP|Source IP Range|Destination IP Range|User Agent] Opt In / Opt Out` lattice, the `Slack HTTPS Scanning …` and `Trial Run HTTPS Scanning …` staged-rollout variants, `AllowChatGPT.domains/.urls`, `AllowTikTok:Domains`/`AllowTikTok URLs`, `AllowListProd_CVS`/`DenyListProd_CVS`/`NoAuthProd_CVS`/`NoAuthProd_hCVS` (Domains + URLs), `PROD_admURL_allow_CVS` (Domains + urls), `Logmein CVS Domains`, `Slack Allowed Workspaces`, `CVS-epicallow`, `Bypass by Source/Destination IP for Troubleshooting`, `Troubleshooting Domain Bypass`.

**Every one of these 234 objects is a `CUSTOMER_MAINTAINED` stub with empty `<content/>` in both backups — see §2 and Appendix D.**

### 10.3 `lists/subscribed_lists/update_server/*.xml` (vendor-maintained)
34 (Aetna) / 36 (CVS). Confirmed vendor infrastructure only (WebEx/Citrix/Windows-Update IP ranges, McAfee-maintained CA bundle) — not itemized further; carries no policy signal.

---

## Appendix A — DLP Dictionary Contents (verbatim)

*(16 Aetna objects, 41 CVS objects — every literal keyword and every regex pattern, extracted directly from each `com.scur.engine.dlpdict.*.xml` object's `dictlist` property.)*

### A.1 — Aetna (selected high-value entries; full 16-object set available on request in spreadsheet form)
- **CVS Health HICN** — `regex(([a-zA-Z]{0,3})[-]?(\d{3})[- ]?(\d{2})[- ]?(\d{4})[- ]?([a-zA-Z]{1,2})[- ]?([0-9]?)\b)`
- **CVS Health HICN Keywords** — 12 literal keyword entries: `Medicare HIC`, `Medicare HICN`, `HICN`, `Health Insurance Claim Number`, `HIC Number`, `Medicare Health Insurance Claim Number`, `Medicate HIC Number`, `hic no`, `hic#`, `hic no.`, `hicn#`, `hicno#`
- **CVS Health Member ID** — `regex([Ww]\d{9})`, `regex([Ww]\d{9}\?)`
- **CVS Health Long Member ID** — `regex([Ww]0{1,4}\d{9})`
- **CVS Health GEMS ID** — `regex([Gg]0\d{9})`
- **CVS Health Dependent ID** — `regex([Ww]\d{11})`
- **CVS Health FIUO Keywords** — `For Internal Use Only`
- **CVS Health GEMS ID Exclusions / HICN Exclusions** — placeholder value `abcdxyz1234!$%` (see flag below)

**Data-quality flag:** several single-entry Aetna exclusion dictionaries (`CVS Health GEMS ID Exclusions`, `CVS Health HICN Exclusions`) contain only the literal string `abcdxyz1234!$%` — this reads as an unpopulated placeholder rather than a real production exclusion set, not a meaningful business value.

### A.2 — CVS (selected entries beyond Aetna's coverage)
- **DLP Routing Number Regex**, **DLP IBAN Regex**, **DLP CID Regex** — ABA/IBAN/CID pattern checks with no Aetna equivalent at all
- **CVS Health AWS Keys**, **CVS Health Passwords** — credential-detection dictionaries absent from Aetna
- **CVS Health Bank Account Number** (+ Keywords/Exclusions variants) — full banking-PII coverage absent from Aetna
- **HICN RegEx / HICN Terms**, **DLP SID Regex AETH S ID [1/2]**, **DLP AID Regex AETH A ID [1/2]** — a legacy Aetna-subscriber/account-ID regex family retained under CVS's numbering, predating the current `CVS Health *` naming convention

*(Complete verbatim 41-entry dictionary set and the 12 built-in classification-category cross-references were extracted in full during this session; happy to re-render the full table if you want every one of the ~400 individual pattern rows inline rather than the representative sample above — it runs long enough that it's better suited to the spreadsheet already produced.)*

---

## Appendix B — DLP Classification Categories (built-in vendor category references)

Skyhigh's `dlpcat.conf` objects aggregate built-in, vendor-maintained checksum-validated detectors (`com.scur.dlpcategory.N`) alongside the custom dictionaries in Appendix A.

| Classification | Estate | Built-in categories referenced (with embedded vendor description where present) |
|---|---|---|
| CVS Health SSN | Both (Aetna id 3099 / CVS id 1204, identical refs) | `#49`, `#16`, `#19` — all "Social Security number with SSA Check and Keyword Check" |
| SSN & PCI | CVS only | `#57` (ABA routing number, checksum+keyword), `#131` (medical-diagnosis-adjacent SSN), `#49` (SSN), `#14`/`#67`/`#48` (Credit Card, Luhn-check, incl. a >100-count numerical threshold variant) |
| DLP Classification: HIPAA | CVS only | `#130`, `#17`, `#31`, `#30`, `#131`, `#49` (SSN), `#14` (Credit Card), `#16` (SSN) |
| DLP Classification: SOX | CVS only | `#35`, `#33`, `#36`, `#21`, `#22`, `#25`, `#26`, `#27`, `#18`, `#28` |
| SSNs | CVS only | `#70` (SSN with >100-count numerical threshold), `#49` (SSN) |
| DLP Dictionary: Acceptable Use | Both (Aetna id 3020 / CVS id 1003, identical refs) | `#9`, `#11`, `#141`, `#13` |
| DLP Classification: Payment Card Industry | Aetna only (named separately from CVS's PCI-via-`SSN & PCI` aggregation) | `#48` (Credit Card, Luhn-check) |

**Read:** CVS's classification layer is substantially deeper — it has dedicated HIPAA and SOX aggregation objects and a combined SSN-and-PCI classification, none of which Aetna's proxy carries. Aetna's PCI coverage exists but only as a single-category object, not folded into a broader classification framework the way CVS's is.

---

## Appendix C — Static IP / IP-Range / Proxy-Chain / ICAP-Server Objects (verbatim)

*(Full extraction already delivered in this conversation — reproduced here by reference for completeness of this consolidated report rather than re-pasted in full.)*

- **Aetna:** 7 `com.scur.type.ip` objects (e.g. `Bypass source IP` — 13 entries incl. named individual troubleshooting IPs tied to incident tickets; `Client_ips_to_bypass`; `CTE 2 IP` — 13 entries all attributed to one named individual), 21 `com.scur.type.iprange` objects (incl. `pdcp-proxies-subnet` = `206.213.226.0/24`, `RuleTracing: Client IPRange` = `10.112.168.61/32`), 2 `nexthopproxy` objects with literal hardcoded proxy-chain IPs (e.g. `midq-proxy-112` → `206.213.248.139:9119`), 6 `icapserver` objects with embedded IPs (e.g. `icaps://10.80.148.125:1344/REQMOD`).
- **CVS:** 7 `ip` objects, 20 `iprange` objects (incl. `F5 load balancer VIP` = `10.93.0.249`, `10.6.65.4` etc., annotated as `westproxies.cvshealth.com`/`eastproxies.cvshealth.com` source IPs; `F5 load balancer VIP_IP Range` = `10.93.0.0/24` "Shea LB", `10.6.65.0/24` "RI LB"), 0 `nexthopproxy` objects, 5 `icapserver` objects (incl. the `0.0.0.0:1344` placeholders flagged in §7).

**Data-quality flags already surfaced:** `pdcp-proxies` (Aetna) is a typed `ip` list with zero entries despite being referenced by name elsewhere; several Aetna bypass-IP lists carry per-entry annotations naming specific employees and incident ticket numbers (e.g. `INC24993890 - Prakash Vijapur`) — these look like one-off troubleshooting exceptions that were never cleaned up and are worth a review pass independent of any CVS comparison.

---

## Appendix D — Externally-Fetched List Inventory (`CUSTOMER_MAINTAINED`, contents not recoverable from these backups)

All 100 (Aetna) / 129 (CVS) objects in `lists/subscribed_lists/customer/` fetch from `proxyconsole.aetna.com`. Representative entries (full 229-object URL table extracted; abbreviated here):

| List | Estate | Source URL | Refresh interval |
|---|---|---|---|
| AllowListProd: Domains | Aetna | `https://proxyconsole.aetna.com/prod/AllowListProd.domains.txt` | 20 min |
| AllowCerts: Domains | Aetna | `https://proxyconsole.aetna.com/prod/AllowCerts.domains.txt` | 20 min |
| VDMZDenyList: Domains | Aetna | `https://proxyconsole.aetna.com/prod/VDMZ_DenyList.Domains.txt` | 20 min |
| OperationBlock:Urls | Aetna | `https://proxyconsole.aetna.com/prod/operationblock.urls.txt` | 2 min |
| ApprovedCloudStorage: Domains | CVS | `https://proxyconsole.aetna.com/prod/ApprovedCloudStorage.domains.txt` | 20 min |
| AllowListProd_CVS: Domains | CVS | `https://proxyconsole.aetna.com/prod/AllowListProd_CVS.domains.txt` | 20 min |
| Trial Run HTTPS Scanning Domain REGEX Opt In | CVS | `https://proxyconsole.aetna.com/MANUAL/HTTPSScanningOptIn/PSSRetail/trialrun/TrialRunHTTPSScanningDomainREGEXOptIn.txt` | 20 min |
| Prod_TenantR: Domains | CVS | `https://proxyconsole.aetna.com/prod/Prod_TenantR.domains.txt` | 20 hours |

**To get the actual content-inspection targeting data (which domains are actually in `AllowListProd`, `ProdSSLinspect`, or any `HTTPS Scanning Opt In` list), the source of truth is `proxyconsole.aetna.com` directly, or a live `list export` from the running appliance — not this backup format, regardless of how it's re-parsed.**

---

## Appendix E — Certificate/CA Objects

- **`Certificate Whitelist`** — has real embedded content on both sides (not a stub). Confirmed live example from Aetna: a whitelisted cert for host `secureemail.pncsecureemail.com`.
- **`Extended.TrustedCAs`** and **`Default known certificate authorities`** — both contain embedded X.509 certs, but inspection confirms these are copies of the standard public root-CA bundle (Comodo, DigiCert, GlobalSign, Entrust, GeoTrust, etc.) shipped with the product — not customer-added internal CAs. Not a source of policy divergence between the two estates; not itemized further here since it's vendor boilerplate, ~190KB per side.

---

## Summary Table

| Dimension | Aetna | CVS | Materially different? |
|---|---|---|---|
| SWG build | 12.2.23-57025 | 12.2.23-57025 | No |
| Cluster size | 15 nodes | 8 nodes | Yes |
| Auth model | NTLM-only + static bypass | Kerberos-first, 3 proxy modes | **Yes** |
| Default decrypt posture | Categorical, decrypt-by-default | Opt-in, tiered, staged rollout | **Yes — largest divergence** |
| SSL-Inspect-Cat contents | 9 categories incl. Content Server | 8 categories, no Content Server | Yes (found via ID resolution) |
| DLP dictionary/classification breadth | 16 dicts / 4 classes (PII/PCI only) | 41 dicts / 9 classes (+banking, credentials, HIPAA, SOX) | **Yes** |
| AV engine tiers | 9 objects, internal 80/85 inconsistency | 2 objects, flat 90 | Yes |
| ICAP direction coverage | REQMOD only | REQMOD + RESPMOD + Symantec | **Yes — coverage gap** |
| Dynamic list infrastructure | proxyconsole.aetna.com | proxyconsole.aetna.com (same) | No — shared, unmigrated |
| Legacy Aetna-DMZ bypass | Enabled | Disabled | Yes (active hardening evidence) |

### Open items requiring a live-system check (not resolvable from either backup)
1. Aetna's "Certificate Verification - Monitor Only" rule group compiles to `Block` actions — confirm actual live behavior against the appliance UI.
2. CVS's `ReqMod Server`/`RespMod Server` ICAP objects resolve to `0.0.0.0` — confirm whether a per-node override supplies the real IP or these calls are currently non-functional.
3. Actual contents of all 234 `CUSTOMER_MAINTAINED` lists (§2, Appendix D) — must be pulled from `proxyconsole.aetna.com` or a live appliance export.
4. Aetna's internal AV threat-rating inconsistency (High Setting = 85 vs. 80) — reconcile independent of CVS.
